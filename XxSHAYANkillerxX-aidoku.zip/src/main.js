export default class MyPersonal {
    async getMangaList() {
        return [];
    }
}
